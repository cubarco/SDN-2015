Problem 2.1
===

commad-line
---
```terminal
# python ./setup_network.py
$ ryu-manager ryu.app.simple_switch_13 ./2_1.py
```
