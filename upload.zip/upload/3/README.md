Problem 3
===

How to use?
---
- Run fakedns.py with a dns.conf on a host with internet access
- Set dnsserver to the mac address of that host
- Run ryu as following:
```
ryu-manager 3.py
```
